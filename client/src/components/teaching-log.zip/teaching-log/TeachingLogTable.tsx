import { Eye, Pencil, Trash2, Calendar, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { TeachingLog } from '../../types/teachingLog.types';
import StatusBadge from './StatusBadge';
import { formatDate } from '../../lib/utils';

interface TeachingLogTableProps {
  logs: TeachingLog[];
  total: number;
  page: number;
  limit: number;
  onPageChange: (page: number) => void;
  onDeleteClick: (id: string) => void;
  readOnly?: boolean;
}

export default function TeachingLogTable({
  logs,
  total,
  page,
  limit,
  onPageChange,
  onDeleteClick,
  readOnly = false,
}: TeachingLogTableProps) {
  const navigate = useNavigate();
  const totalPages = Math.ceil(total / limit);

  const handlePrevPage = () => {
    if (page > 1) onPageChange(page - 1);
  };

  const handleNextPage = () => {
    if (page < totalPages) onPageChange(page + 1);
  };

  return (
    <div className="bg-white rounded-xl border border-gray-100 overflow-hidden flex flex-col shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50 text-gray-600 font-semibold">
              <th className="px-6 py-4">Date</th>
              <th className="px-4 py-4">Subject</th>
              <th className="px-4 py-4">Class & Sec</th>
              <th className="px-4 py-4">Topic Taught</th>
              <th className="px-4 py-4">Lesson Objective</th>
              <th className="px-4 py-4">Homework</th>
              <th className="px-4 py-4">Status</th>
              <th className="px-4 py-4">Logged By</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {logs.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center py-12 text-gray-400">
                  No teaching logs found.
                </td>
              </tr>
            ) : (
              logs.map((log) => (
                <tr key={log._id} className="border-b border-gray-55 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900 flex items-center gap-2">
                    <Calendar size={14} className="text-gray-400" />
                    {formatDate(log.date)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap font-medium text-gray-800">{log.subject}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-gray-600">
                    <span className="bg-gray-100 text-gray-750 px-2 py-0.5 rounded text-xs font-semibold">
                      {log.classId}-{log.section}
                    </span>
                  </td>
                  <td className="px-4 py-4 max-w-[180px] truncate font-medium text-gray-900" title={log.topicTaught}>
                    {log.topicTaught}
                  </td>
                  <td className="px-4 py-4 max-w-[200px] truncate text-gray-500 italic" title={log.lessonObjective}>
                    {log.lessonObjective}
                  </td>
                  <td className="px-4 py-4 max-w-[150px] truncate text-gray-600" title={log.homeworkGiven}>
                    {log.homeworkGiven ? (
                      <span className="flex items-center gap-1.5">
                        <FileText size={13} className="text-green-550 shrink-0" />
                        <span className="truncate">{log.homeworkGiven}</span>
                      </span>
                    ) : (
                      <span className="text-gray-405 text-xs">-</span>
                    )}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <StatusBadge status={log.status} />
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-gray-600 text-xs">
                    <div className="font-semibold text-gray-800">{log.createdBy.name}</div>
                    <div className="text-[10px] text-gray-400">{log.createdBy.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-xs font-medium">
                    <div className="flex justify-end gap-2.5">
                      <button
                        onClick={() => navigate(`/teaching-log/${log._id}${readOnly ? '?readonly=1' : ''}`)}
                        className="text-gray-400 hover:text-green-600 p-1 rounded hover:bg-gray-100 transition-colors"
                        title="View Details"
                      >
                        <Eye size={15} />
                      </button>
                      {!readOnly && (
                        <>
                          <button
                            onClick={() => navigate(`/teaching-log/${log._id}/edit`)}
                            className="text-gray-400 hover:text-blue-600 p-1 rounded hover:bg-gray-100 transition-colors"
                            title="Edit Log"
                          >
                            <Pencil size={15} />
                          </button>
                          <button
                            onClick={() => onDeleteClick(log._id)}
                            className="text-gray-400 hover:text-red-650 p-1 rounded hover:bg-gray-100 transition-colors"
                            title="Delete Log"
                          >
                            <Trash2 size={15} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      {totalPages > 1 && (
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            Showing <span className="font-semibold text-gray-900">{Math.min((page - 1) * limit + 1, total)}</span> to{' '}
            <span className="font-semibold text-gray-900">{Math.min(page * limit, total)}</span> of{' '}
            <span className="font-semibold text-gray-900">{total}</span> records
          </p>

          <div className="flex gap-2">
            <button
              onClick={handlePrevPage}
              disabled={page === 1}
              className="p-1.5 rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }).map((_, i) => {
              const p = i + 1;
              const isCurrent = p === page;
              return (
                <button
                  key={p}
                  onClick={() => onPageChange(p)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors border ${
                    isCurrent
                      ? 'bg-green-600 text-white border-green-600 shadow-sm'
                      : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {p}
                </button>
              );
            })}
            <button
              onClick={handleNextPage}
              disabled={page === totalPages}
              className="p-1.5 rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
