import { Search, RefreshCw } from 'lucide-react';
import { TeachingLogFilters as FilterTypes, TeachingLogStatus } from '../../types/teachingLog.types';

interface TeachingLogFiltersProps {
  filters: FilterTypes;
  onFilterChange: (filters: FilterTypes) => void;
  onReset: () => void;
  classOptions?: string[];
  subjectOptions?: string[];
}

export default function TeachingLogFilters({
  filters,
  onFilterChange,
  onReset,
  classOptions = [],
  subjectOptions = [],
}: TeachingLogFiltersProps) {
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ search: e.target.value });
  };

  const handleClassChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ classId: e.target.value });
  };

  const handleSubjectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ subject: e.target.value });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ status: e.target.value as TeachingLogStatus | '' });
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ date: e.target.value });
  };

  const selectCls =
    'border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent min-w-[140px] cursor-pointer';

  return (
    <div className="bg-white rounded-xl border border-gray-100 p-4 mb-5 flex items-center gap-3 flex-wrap">
      {/* Search */}
      <div className="relative flex-1 min-w-[200px]">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="Search logs (topic, objective, teacher...)"
          value={filters.search || ''}
          onChange={handleSearchChange}
          className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
        />
      </div>

      {/* Class Filter */}
      <select value={filters.classId || ''} onChange={handleClassChange} className={selectCls}>
        <option value="">All Classes</option>
        {classOptions.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>

      {/* Subject Filter */}
      <select value={filters.subject || ''} onChange={handleSubjectChange} className={selectCls}>
        <option value="">All Subjects</option>
        {subjectOptions.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>

      {/* Status Filter */}
      <select value={filters.status || ''} onChange={handleStatusChange} className={selectCls}>
        <option value="">All Statuses</option>
        <option value="completed">Completed</option>
        <option value="draft">Draft</option>
      </select>

      {/* Date Filter */}
      <input
        type="date"
        value={filters.date || ''}
        onChange={handleDateChange}
        className="border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent cursor-pointer"
      />

      {/* Reset Button */}
      <button
        onClick={onReset}
        title="Reset Filters"
        className="flex items-center justify-center border border-gray-200 hover:border-orange-400 rounded-lg p-2.5 text-gray-550 hover:bg-orange-50 hover:text-orange-500 transition-colors font-medium cursor-pointer"
      >
        <RefreshCw size={16} />
      </button>
    </div>
  );
}
