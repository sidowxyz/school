import { useState } from 'react';
import { Clock, ChevronDown, Loader2 } from 'lucide-react';
import type { TeacherAssignment } from '@/features/teachers/types';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;
type Day = (typeof DAYS)[number];

export default function TimetableTab({
  assignments,
  loading = false,
}: {
  assignments: TeacherAssignment[];
  loading?: boolean;
}) {
  const [day, setDay] = useState<Day>('Monday');

  const periods = assignments
    .flatMap((a) => a.timetableSlots
      .filter((slot) => slot.day === day && slot.periodId)
      .map((slot) => ({
        subject: a.subjectId?.sub_name || '—',
        class: `${a.classId?.cl_name || '—'}${a.sectionId?.name ? ` - ${a.sectionId.name}` : ''}`,
        periodName: slot.periodId.per_name,
        startTime: slot.periodId.time_in,
        endTime: slot.periodId.time_out,
      })))
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  return (
    <div className="bg-white rounded-xl border border-gray-150 p-5 shadow-sm">
      <h2 className="font-semibold text-gray-800">My Weekly Timetable</h2>
      <p className="text-sm text-gray-400 mb-4">
        Your complete teaching schedule - {periods.length} period{periods.length === 1 ? '' : 's'} on {day}
      </p>

      <div className="relative mb-5">
        <select
          value={day}
          onChange={(e) => setDay(e.target.value as Day)}
          className="w-full appearance-none border border-gray-200 rounded-lg px-4 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-green-400"
        >
          {DAYS.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
      </div>

      {loading ? (
        <div className="text-center py-10 text-gray-500 text-sm flex items-center justify-center gap-2">
          <Loader2 size={18} className="animate-spin text-green-600" /> Loading your timetable...
        </div>
      ) : periods.length === 0 ? (
        <div className="text-center py-10 text-gray-500 text-sm">No periods scheduled for {day}.</div>
      ) : (
        <div className="space-y-3">
          {periods.map((p) => (
            <div
              key={`${p.periodName}-${p.class}-${p.startTime}`}
              className="flex items-center gap-4 bg-gradient-to-r from-blue-50/40 to-green-50/40 border border-gray-100 rounded-xl p-4"
            >
              <div className="w-14 h-14 bg-blue-600 rounded-xl flex flex-col items-center justify-center text-white shrink-0">
                <Clock size={16} />
                <span className="text-[10px] leading-none mt-1">{p.periodName}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-gray-900">{p.class}</p>
                <p className="text-sm text-gray-500">{p.subject}</p>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="inline-flex items-center gap-1 bg-green-600 text-white text-xs px-2 py-0.5 rounded">
                    <Clock size={11} /> {p.startTime} - {p.endTime}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
